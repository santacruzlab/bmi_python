import array
import ctypes
from enum import unique, IntEnum
import itertools
import logging
import time

import xipppy_capi as _c
from .exception import check

logger = logging.getLogger(__name__)

TRANSCEIVER_STATUS_COUNTER_MAX = 255
IMPLANT_BOOTING_COUNTER_MAX = 10
DEFAULT_SERVO_DAC_LEVEL = 0x92

POWER_STATE_R3 = {
    'idle': 0,
    'ir_enable': 1,
    'coil_enable': 2,
    'servo_enable': 3,
    'booting_coil_on': 4,
    'booting_coil_off': 5
}

IMPLANT_VOLTAGE_STATE = {
    'default': 3.5,
    'boosted': 4.0
}


class TransceiverCmdHeader:
    CMD = 0xc << 12
    IMPLANT_WRITE = CMD | (0b10 << 4)
    TRANSCEIVER_WRITE = CMD | (0b01 << 4)
    IMPLANT_READ = IMPLANT_WRITE | 0b01
    TRANSCEIVER_READ = TRANSCEIVER_WRITE | 0b01


class TransceiverRegisterAddrs:
    DEMOD_LATCH_DELAY_COUNT = 0x01
    COIL_PULSE_WIDTH = 0x02
    COIL_BLANK_COUNT = 0x03
    MANUAL_CONTROL_COIL_IR = 0x04
    COIL_ENABLE_BITS = 0x05
    IR_ENABLE_BITS = 0x06
    COIL_DRIVE_DAC = 0x07
    DEMOD_FILTER_DISABLE = 0x08
    POWER_SUPPLY_ENABLE_5V = 0x09
    COIL_BLANK_PERIOD = 0x0a
    LINK_ENABLE_COIL_IR = 0x0b
    IMPLANT_SERVO_DAC_TARGET = 0x0c
    IMPLANT_SERVO_ENABLE = 0x0d


class ImplantRegisterAddrs:
    # Non-ASIC
    IMPEDANCE_CONTROL = 0x1
    FAST_SETTLE_ENABLE = 0x2
    LED_PROM_CONFIG = 0x15
    RECORDING_RESOLUTION = 0x40
    # ASIC
    AMP_LOWER_BANDWIDTH_SELECT = 0x100
    AMP_UPPER_BANDWIDTH_SELECT_1 = 0x101
    AMP_UPPER_BANDWIDTH_SELECT_2 = 0x102
    AMPLIFIER_POWER_1 = 0x103
    AMPLIFIER_POWER_2 = 0x104
    MUX_BIAS_CURRENT_AND_COUNTER = 0x105
    IMPEDANCE_CHECK = 0x106
    ROM_CHECKSUM_2 = 0x0117  # Read only
    ROM_CHECKSUM_1 = 0x0118  # Read only
    NUM_AMPLIFIERS = 0x119  # Read only


@unique
class TransceiverStatus(IntEnum):
    NOT_USED = 0
    REGISTER_ADDR = 1
    REGISTER_DATA = 2
    RNUM = 3
    SERIAL_NUM = 4
    HW_FW_VER = 5
    IR_LIGHT_AMP_AND_SERVO_STATE = 6
    TEMP_AND_RESERVED = 7
    INPUT_SUPPLY_CURRENT_AND_VOLTAGE_ADC = 8
    COIL_SUPPLY_CURRENT_AND_VOLTAGE_ADC = 9
    RESERVED_1 = 10
    RESERVED_2 = 11
    IMPLANT_RNUM = 12
    IMPLANT_SERIAL_NUM = 13
    IMPLANT_FW_HW_VER = 14
    IMPLANT_CURRENT_AND_VOLTAGE_ADC = 15
    IMPLANT_PACKET_COUNT = 16
    MICS_CONF_LED_PROM = 17
    SARA_ASIC_STATUS = 18
    SARA_IMPLANT_2_6_V_CURRENT_AND_VOLTAGE_ADC = 19
    SARA_STIM_NEG_AND_POS_VOLTAGE_ADC = 20
    SARA_STIM_CURRENT_ADC = 21
    SARA_IMPEDANCE_STATUS = 22
    SARA_IMPEDANCE_FREQ_AND_CLOCK_SKEW = 23
    SARA_HUMID_AND_TEMP = 24
    RESERVED_3 = 25
    RESERVED_4 = 26
    RESERVED_5 = 27
    RESERVED_6 = 28
    RESERVED_7 = 29
    RESERVED_8 = 30
    RESERVED_9 = 31


class TransceiverCommand:
    MIN_I16 = -32768
    MAX_U16 = 65535

    def __init__(self, command=0, data=None):
        if data is None:
            data = []

        self.command = command
        self._data = []

        self.data = data

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, new_data):
        data = []

        for n in new_data:
            n = int(n)
            if n < self.MIN_I16 or n > self.MAX_U16:
                raise TypeError('unable to convert data to an int16')

            val = ctypes.c_uint16(n)
            data.append(val.value)

        self._data = data

    @property
    def length(self):
        return len(self._data)

    def cast(self):
        cmd = _c.XippTransceiverCommand_t()
        cmd.command = self.command
        cmd.length = self.length
        cmd.data = self.data
        return cmd


def transceiver_enable(front_end, enable=True):
    """
    Enable or disable front end at position front_end

    Parameters
    ----------
    front end: int
        integer 0..15 specifying which front end. 0 is A1 and 15 is D4

    enable: boolean
        flag whether to enable or disable the front end
    """

    check(_c.xl_transceiver_enable(int(front_end), bool(enable)))


def transceiver_status(front_end):
    """
    Get most recent status from transceiver at position front_end

    Parameters
    ---------
    front end: int
        integer 0..15 specifying which front end.  0 is A1 and 15 is D4

    returns: array of uint16_t containing the status
    """

    result = array.array('H', itertools.repeat(0, 32))
    check(_c.xl_transceiver_status(result.buffer_info()[0], front_end))
    return result


def transceiver_command(front_end, command):
    """
    Send command to transceiver at position front_end

    Parameters
    ----------
    front end: int
        integer 0..15 specifying which front end.  0 is A1 and 15 is D4

    command: TransceiverCommand
        object of type TransceiverCommand specifying the command to send
    """

    if isinstance(command, TransceiverCommand):
        cmd_t = command.cast()
    elif isinstance(command, _c.XippTransceiverCommand_t):
        cmd_t = command
    else:
        raise ValueError('command is required to be Transceiver command type')

    check(_c.xl_transceiver_command(front_end, cmd_t))


def high_byte(light_servo):
    return light_servo & 0b1111111100000000


def low_byte(light_servo):
    return light_servo & 0b0000000011111111


def transceiver_power_servo_enable(state: bool) -> None:
    """
    This sets the implant power servo state. This ultimately affects a property
    of the implant. But, the state is held in a transceiver register so it
    persists through implant restarts due to power loss.

    :param state: True for enabled, False for disabled.
    """
    cmd = TransceiverCommand(
        TransceiverCmdHeader.TRANSCEIVER_WRITE,
        [0, TransceiverRegisterAddrs.IMPLANT_SERVO_ENABLE, int(state)]
    )
    transceiver_command(0, cmd)


def transceiver_get_ir_received_light(front_end: int = 0) -> float:
    """
    Return the light amplitude, in arbitrary voltage units, that is measured
    by the transceiver photodiode.
    """
    light_servo = transceiver_status(front_end)[
        TransceiverStatus.IR_LIGHT_AMP_AND_SERVO_STATE
    ]
    light_adc = light_servo & 0b1111111000000
    scaled_volt = light_adc * (1 / 256.0) * 4.096
    return scaled_volt


def transceiver_get_power_state(front_end: int = 0) -> int:
    """
    Return the power state for the implant. This can be used to detect whether
    the implant is booted. See POWER_STATE_R3 for mapping of descriptions to
    power state number returned by this function.
    """
    light_servo = transceiver_status(front_end)[
        TransceiverStatus.IR_LIGHT_AMP_AND_SERVO_STATE
    ]
    servo = light_servo & 0b111
    return servo


def transceiver_get_implant_voltage(front_end: int = 0) -> float:
    """
    Return the current power supply voltage for the connected implant.
    """
    curr_volt_adc = transceiver_status(front_end)[
        TransceiverStatus.IMPLANT_CURRENT_AND_VOLTAGE_ADC
    ]
    volt_adc = low_byte(curr_volt_adc)
    scaled_volts = (2.5 * ((float(volt_adc)) / 256)) / (57.6 / (76.8 + 57.6))
    return scaled_volts


def transceiver_get_implant_serial(front_end: int = 0) -> int:
    """
    Return the connected implant serial number.
    :return:
    """
    return transceiver_status(front_end)[TransceiverStatus.IMPLANT_SERIAL_NUM]


def transceiver_get_ir_led_level(front_end: int = 0) -> int:
    """
    Query the current IR LED light level reported by the transceiver. The value
    is in the range 0 to 15 inclusive. But, the low levels, especially 0 can
    never been reported as real values because the IR is used to report the
    light levels, so it's impossible to report light levels below a certain
    level.
    """
    mics_led = transceiver_status(front_end)[
        TransceiverStatus.MICS_CONF_LED_PROM
    ]
    # Mask out the MICS part.
    led = mics_led & 0b0000000011111111
    return led


def transceiver_set_implant_servo_dac(
        target: int = DEFAULT_SERVO_DAC_LEVEL) -> None:
    """
    Set the target DAC value for the transceiver coil driver voltage.


    :param target: Set the target DAC value. If this value is None, then the
    default, 0x92, is set.
    """
    cmd = TransceiverCommand(
        TransceiverCmdHeader.TRANSCEIVER_WRITE,
        [0, TransceiverRegisterAddrs.IMPLANT_SERVO_DAC_TARGET, target]
    )
    transceiver_command(0, cmd)


def transceiver_enable_ir_coil(target: int):
    """
    Switch ir-link between transceiver and implants
    :param target: True for On, False for Off
    """
    cmd = TransceiverCommand(
        TransceiverCmdHeader.TRANSCEIVER_WRITE,
        [0, TransceiverRegisterAddrs.LINK_ENABLE_COIL_IR, target]
    )
    transceiver_command(0, cmd)


def _ensure_implant_voltage_settled():
    # only useful if MIRA implant is already booted.
    transceiver_set_implant_servo_dac(DEFAULT_SERVO_DAC_LEVEL)
    transceiver_power_servo_enable(True)

    for _ in range(IMPLANT_BOOTING_COUNTER_MAX):
        imp_v = transceiver_get_implant_voltage()
        if imp_v <= IMPLANT_VOLTAGE_STATE['default']:
            return True
        else:
            logger.debug(
                'Waiting for implant voltage to settle (imp_v={})'
                    .format(imp_v))
        time.sleep(0.33)

    return False


def ensure_implant_booted():
    """
    This function ensure that a MIRA implant is booted and settled. This
    function will return False if the implant could not be booted in the
    retry limit. True otherwise. An exception is not thrown if the implant is
    not booted. A xipppy_open context must be entered before calling this
    function.
    """
    for _ in range(IMPLANT_BOOTING_COUNTER_MAX):
        power_st = transceiver_get_power_state()
        if power_st == POWER_STATE_R3['servo_enable']:
            logger.debug("Implant is booted.")
            if _ensure_implant_voltage_settled():
                return True
        elif power_st == POWER_STATE_R3['idle']:
            logger.debug('Implant is down, booting.')
            transceiver_enable(0, True)
        else:
            logger.debug('Implant is booting.')
        time.sleep(0.5)

    return False
